class GeometricObject {
    private String color;
    private boolean filled;

    public GeometricObject() {
        this.color = "white";
        this.filled = false;
    }

    public GeometricObject(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }
}

class Octagon extends GeometricObject implements Comparable<Octagon>, Cloneable {
    private double side;

    public Octagon(double side) {
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    public double getArea() {
        return (2 + 4 / Math.sqrt(2)) * side * side;
    }

    public double getPerimeter() {
        return 8 * side;
    }

    @Override
    public int compareTo(Octagon other) {
        if (this.getArea() > other.getArea())
            return 1;
        else if (this.getArea() < other.getArea())
            return -1;
        else
            return 0;
    }

    @Override
    public Octagon clone() throws CloneNotSupportedException {
        return (Octagon) super.clone();
    }
}

public class TestOctagon {
    public static void main(String[] args) {
        Octagon octagon1 = new Octagon(5.0);

        try {
            Octagon octagon2 = octagon1.clone();
            int comparison = octagon1.compareTo(octagon2);

            System.out.println("Octagon 1 area: " + octagon1.getArea());
            System.out.println("Octagon 2 area: " + octagon2.getArea());

            if (comparison > 0)
                System.out.println("Octagon 1 is larger than Octagon 2");
            else if (comparison < 0)
                System.out.println("Octagon 1 is smaller than Octagon 2");
            else
                System.out.println("Octagon 1 is equal to Octagon 2");
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
