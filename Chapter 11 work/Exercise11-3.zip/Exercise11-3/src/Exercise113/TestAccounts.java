package Exercise113;
public class TestAccounts {
    public static void main(String[] args) {
        Account account = new Account(1122, 20000);
        account.setAnnualInterestRate(4.5);

        account.withdraw(2500);
        account.deposit(3000);

        System.out.println(account.toString());

        SavingsAccount savingsAccount = new SavingsAccount(1123, 15000);
        savingsAccount.setAnnualInterestRate(3.0);

        savingsAccount.withdraw(2000);
        savingsAccount.deposit(500);

        System.out.println(savingsAccount.toString());

        CheckingAccount checkingAccount = new CheckingAccount(1124, 10000, 2000);
        checkingAccount.setAnnualInterestRate(2.5);

        checkingAccount.withdraw(12000);
        checkingAccount.withdraw(500);

        System.out.println(checkingAccount.toString());
    }
}