package Exercise113;

public class SavingsAccount extends Account {
    public SavingsAccount() {
        super();
    }

    public SavingsAccount(int id, double balance) {
        super(id, balance);
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= getBalance()) {
            super.withdraw(amount);
        } else {
            System.out.println("Error: Insufficient funds in the savings account.");
        }
    }

    @Override
    public String toString() {
        return "Savings Account: " + super.toString();
    }
}

