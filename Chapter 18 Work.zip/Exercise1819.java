
public class Exercise1819 {

}
