public class Exercise103 {
    public static void main(String[] args) {
        int value = 12;
        MyInteger num1 = new MyInteger(7);
        MyInteger num2 = new MyInteger(13);
        char[] num3 = {'1', '2', '3', '4'};

        System.out.println("num1.getValue() = " + num1.getValue());

        System.out.println("num1.isEven() = " + num1.isEven());
        System.out.println("num1.isOdd() = " + num1.isOdd());
        System.out.println("num1.isPrime() = " + num1.isPrime());

        System.out.println("MyInteger.isEven(value) = " + MyInteger.isEven(value));
        System.out.println("MyInteger.isOdd(value) = " + MyInteger.isOdd(value));
        System.out.println("MyInteger.isPrime(value) = " + MyInteger.isPrime(value));

        System.out.println("MyInteger.isEven(num1) = " + MyInteger.isEven(num1));
        System.out.println("MyInteger.isOdd(num1) = " + MyInteger.isOdd(num1));
        System.out.println("MyInteger.isPrime(num1) = " + MyInteger.isPrime(num1));

        System.out.println("num1.equals(value) = " + num1.equals(value));
        System.out.println("num1.equals(num2) = " + num1.equals(num2));

        System.out.println("MyInteger.parseInt(num3) = " + MyInteger.parseInt(num3));
        System.out.println("MyInteger.parseInt(\"5678\") = " + MyInteger.parseInt("5678"));
    }
}

class MyInteger {
    private int value;

    public MyInteger(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public boolean isEven() {
        return value % 2 == 0;
    }

    public boolean isOdd() {
        return value % 2 != 0;
    }

    public boolean isPrime() {
        if (value == 1 || value == 2) {
            return true;
        }
        for (int i = 2; i < value; i++) {
            if (value % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean isEven(int value) {
        return value % 2 == 0;
    }

    public static boolean isOdd(int value) {
        return value % 2 != 0;
    }

    public static boolean isPrime(int value) {
        if (value == 1 || value == 2) {
            return true;
        }
        for (int i = 2; i < value; i++) {
            if (value % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean isEven(MyInteger myInt) {
        return myInt.isEven();
    }

    public static boolean isOdd(MyInteger myInt) {
        return myInt.isOdd();
    }

    public static boolean isPrime(MyInteger myInt) {
        return myInt.isPrime();
    }

    public boolean equals(int value) {
        return this.value == value;
    }

    public boolean equals(MyInteger myInt) {
        return this.value == myInt.getValue();
    }

    public static int parseInt(char[] chars) {
        int result = 0;
        for (int i = 0; i < chars.length; i++) {
            result = result * 10 + (chars[i] - '0');
	        }
	        return result;
	    }

	    public static int parseInt(String str) {
	        return Integer.parseInt(str);
	    }
}