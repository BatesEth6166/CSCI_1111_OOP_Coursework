import java.util.Scanner;

public class Account {
    private Exercise107 currentAccount;

    public Account(Exercise107 account) {
        this.currentAccount = account;
    }

    public void setCurrentAccount(Exercise107 account) {
        this.currentAccount = account;
    }

    public void getBalance() {
        System.out.println("Balance is $" + currentAccount.getBalance());
    }

    public void deposit() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the amount to deposit: ");
        double depositAmount = scanner.nextDouble();
        currentAccount.deposit(depositAmount);
        System.out.println("Deposited $" + depositAmount);
    }

    public void withdraw() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the amount to withdraw: ");
        double withdrawAmount = scanner.nextDouble();
        if (currentAccount.withdraw(withdrawAmount)) {
            System.out.println("Withdrawn $" + withdrawAmount);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    public static void displayMainMenu() {
        System.out.println("\nMain Menu");
        System.out.println("1. View Balance");
        System.out.println("2. Withdraw Money");
        System.out.println("3. Deposit Money");
        System.out.println("4. Exit");
    }
}
