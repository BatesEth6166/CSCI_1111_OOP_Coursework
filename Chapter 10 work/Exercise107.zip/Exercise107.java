import java.util.Scanner;

public class Exercise107 {
    private int id;
    private double balance;

    public Exercise107(int id, double balance) {
        this.id = id;
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double depositAmount) {
        balance += depositAmount;
    }

    public boolean withdraw(double withdrawAmount) {
        if (withdrawAmount <= balance) {
            balance -= withdrawAmount;
            return true;
        } else {
            return false;
        }
    }

    public static void displayMainMenu() {
        System.out.println("\nMain Menu");
        System.out.println("1. View Balance");
        System.out.println("2. Withdraw Money");
        System.out.println("3. Deposit Money");
        System.out.println("4. Exit");
    }

    public static void main(String[] args) {
        Exercise107[] accounts = new Exercise107[10];

        for (int i = 0; i < accounts.length; i++) {
            accounts[i] = new Exercise107(i, 100);
        }

        Scanner scanner = new Scanner(System.in);
        Account account = new Account(null);

        while (true) {
            System.out.print("Enter an ID: ");
            int id = scanner.nextInt();
            if (id < 0 || id >= accounts.length) {
                System.out.println("Invalid ID. Please enter a correct ID.");
                continue;
            }
            Exercise107 currentAccount = accounts[id];
            account.setCurrentAccount(currentAccount);

            Account.displayMainMenu();
            System.out.print("Enter a choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    account.getBalance();
                    break;
                case 2:
                    account.withdraw();
                    break;
                case 3:
                    account.deposit();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid choice.");
                    break;
            }
        }
    }
}
