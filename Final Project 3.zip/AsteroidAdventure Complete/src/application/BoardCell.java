package application;

import javafx.scene.control.Button;

public class BoardCell extends Button {

    private String name;

    private Type type;

    public BoardCell(Type type) {
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    // Set the style of the button based on the cell type and board dimensions
    public void setStyle(int boardDim1) {
        // Define the minimum size for the cell based on the board dimension
        String minSize = "-fx-min-width: 30px; " +
                "-fx-min-height: 30px;";

        if (boardDim1 > 40)
            minSize = "-fx-min-width: 10px; " +
                    "-fx-min-height: 10px;";
        else if (boardDim1 > 29)
            minSize = "-fx-min-width: 15px; " +
                    "-fx-min-height: 15px;";
        else if (boardDim1 > 19)
            minSize = "-fx-min-width: 20px; " +
                    "-fx-min-height: 20px;";

        // Set the button style based on the cell type
        switch (type) {
            case Ship:
                setStyle("-fx-background-color: blue;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
            case Exit:
                setStyle("-fx-background-color: green;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
            case Pirate:
                setStyle("-fx-background-color: red;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
            case Asteroid:
                setStyle("-fx-background-color: gray;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
            case Treasure:
                setStyle("-fx-background-color: yellow;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
            case Blank:
                setStyle("-fx-background-color: black;" +
                        "-fx-border-color: white; " +
                        "-fx-border-width: 1px; " +
                        "-fx-padding: 2px;" +
                        minSize);
                break;
        }
    }

    @Override
    public String toString() {
        return "BoardCell{" +
                "name='" + name +
                ", type=" + type +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
