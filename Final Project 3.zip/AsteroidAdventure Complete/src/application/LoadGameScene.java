package application;
import javafx.animation.TranslateTransition;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class LoadGameScene {

    public static void createLoadGameScene(Stage primaryStage) {
        // Create the main grid pane for the load game scene
        GridPane loadGamePane = new GridPane();
        loadGamePane.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        loadGamePane.setPadding(new Insets(20));
        loadGamePane.setVgap(10);

        // Create and configure the title label
        Label lblTitle = new Label("Select a game from below to load");
        lblTitle.setTextFill(Color.WHITE);
        lblTitle.setStyle("-fx-font-size: 24px;");
        loadGamePane.add(lblTitle, 1, 0);

        // Create a list view for displaying saved game details
        ListView<String> savedGamesList = new ListView<>();
        loadGamePane.add(savedGamesList, 1, 1);

        // Load saved game details and populate the list view
        List<String> savedGameDetails = loadSavedGameDetails();
        savedGamesList.getItems().addAll(savedGameDetails);

        // Create and configure the load button
        Button loadButton = new Button("Load");
        loadButton.setStyle("-fx-font-size: 14px;");
        loadButton.setCursor(Cursor.HAND);
        loadButton.setOnAction(event -> {
            String selectedGame = savedGamesList.getSelectionModel().getSelectedItem();
            if (selectedGame != null) {
                // Load the selected game and switch to the game scene
                System.out.println("selected game: " + selectedGame);
                GameState gameState = loadSelectedGame(selectedGame);
                GameScene.loadGameScene(primaryStage, gameState);
            }
        });

        // Create and configure the back button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 14px;");
        backButton.setCursor(Cursor.HAND);
        backButton.setOnAction(event -> {
            loadGamePane.setTranslateX(0);
            loadGamePane.setTranslateY(0);
            AsteroidAdventureApp.showMainScreen(primaryStage);
        });

        // Create a grid pane for the load and back buttons
        GridPane loadBackButtonsPane = new GridPane();
        loadBackButtonsPane.setHgap(20);
        loadBackButtonsPane.setAlignment(Pos.CENTER);
        loadBackButtonsPane.add(loadButton, 0, 1);
        loadBackButtonsPane.add(backButton, 1, 1);

        // Add the load and back buttons to the main grid pane
        loadGamePane.add(loadBackButtonsPane, 1, 2);

        // Configure alignment and appearance of the main grid pane
        loadGamePane.setAlignment(Pos.CENTER);
        GridPane.setHalignment(lblTitle, HPos.CENTER);

        // Create the load game scene
        Scene loadGameScene = new Scene(loadGamePane, 950, 700);
        TranslateTransition settingsTransition = new TranslateTransition(Duration.seconds(2), loadGamePane);
        settingsTransition.setFromY(-loadGamePane.getHeight());
        settingsTransition.setToY(0);
        settingsTransition.play();
        primaryStage.setScene(loadGameScene);
        settingsTransition.play();
    }

    // Method to load saved game details
    private static List<String> loadSavedGameDetails() {
        List<String> savedGameDetails = new ArrayList<>();

        // Get the directory where saved games are stored
        File savedGamesDirectory = new File("saved_games");
        if (savedGamesDirectory.exists() && savedGamesDirectory.isDirectory()) {
            File[] savedGameFiles = savedGamesDirectory.listFiles();

            if (savedGameFiles != null) {
                for (File file : savedGameFiles) {
                    if (file.isFile()) {
                        // Add the file name (saved game name) to the list
                        String fileName = file.getName();
                        savedGameDetails.add(fileName);
                    }
                }
            }
        }

        return savedGameDetails;
    }

    // Method to load a selected game
    private static GameState loadSelectedGame(String fileName) {
        GameState loadedGame = null;
        try {
            // Read the selected game file and deserialize the game state
            FileInputStream fileInput = new FileInputStream("saved_games/" + fileName);
            ObjectInputStream objectInput = new ObjectInputStream(fileInput);
            loadedGame = (GameState) objectInput.readObject();
            System.out.println("Loaded game: " + loadedGame);
            objectInput.close();
            fileInput.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return loadedGame;
    }
}
