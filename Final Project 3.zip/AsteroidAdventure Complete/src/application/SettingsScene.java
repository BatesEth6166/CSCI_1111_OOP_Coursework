package application;
import javafx.animation.TranslateTransition;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SettingsScene {
    private static TextField txtMapSize;
    private static TextField txtNumOfPirates;
    private static TextField txtNumOfAsteroids;
    private static TextField txtNumOfTreasures;
    private static TextField txtNumOfMissiles;
    private static TextField txtNumOfBoosters;

    static int MapSize = 10;
    static int NumOfPirates = 1;
    static int NumOfAsteroids = 10;
    static int NumOfTreasures = 5;
    static int NumOfMissiles = 5;
    static int NumOfBoosters = 5;


    public static void createSettingsScene(Stage primaryStage) {
        // Create the main grid pane for the settings scene
        GridPane settingsPane = new GridPane();
        settingsPane.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        settingsPane.setPadding(new Insets(20));
        settingsPane.setVgap(10);

        // Create and configure labels for settings
        Label lblMapSize = new Label("Map Size: ");
        Label lblNumOfPirates = new Label("Number of Pirates: ");
        Label lblNumOfAsteroids = new Label("Number of Asteroids: ");
        Label lblNumOfTreasures = new Label("Number of Treasures: ");
        Label lblNumOfMissiles = new Label("Number of Missiles: ");
        Label lblNumOfBoosters = new Label("Number of Boosters: ");

        lblMapSize.setTextFill(Color.WHITE);
        lblNumOfPirates.setTextFill(Color.WHITE);
        lblNumOfAsteroids.setTextFill(Color.WHITE);
        lblNumOfTreasures.setTextFill(Color.WHITE);
        lblNumOfMissiles.setTextFill(Color.WHITE);
        lblNumOfBoosters.setTextFill(Color.WHITE);

        // Add labels to the grid pane
        settingsPane.add(lblMapSize, 0, 0);
        settingsPane.add(lblNumOfPirates, 0, 1);
        settingsPane.add(lblNumOfAsteroids, 0, 2);
        settingsPane.add(lblNumOfTreasures, 0, 3);
        settingsPane.add(lblNumOfMissiles, 0, 4);
        settingsPane.add(lblNumOfBoosters, 0, 5);

        // Create and configure text fields for settings
        txtMapSize = new TextField("" + MapSize);
        txtNumOfPirates = new TextField("" + NumOfPirates);
        txtNumOfAsteroids = new TextField("" + NumOfAsteroids);
        txtNumOfTreasures = new TextField("" + NumOfTreasures);
        txtNumOfMissiles = new TextField("" + NumOfMissiles);
        txtNumOfBoosters = new TextField("" + NumOfBoosters);

        // Add text fields to the grid pane
        settingsPane.add(txtMapSize, 1, 0);
        settingsPane.add(txtNumOfPirates, 1, 1);
        settingsPane.add(txtNumOfAsteroids, 1, 2);
        settingsPane.add(txtNumOfTreasures, 1, 3);
        settingsPane.add(txtNumOfMissiles, 1, 4);
        settingsPane.add(txtNumOfBoosters, 1, 5);

        // Create and configure save button
        Button saveButton = new Button("Save");
        saveButton.setStyle("-fx-font-size: 14px;");
        saveButton.setCursor(Cursor.HAND);
        saveButton.setOnAction(event -> {
            validateAndSetValues();
        });

        // Create and configure back button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 14px;");
        backButton.setCursor(Cursor.HAND);
        backButton.setOnAction(event -> {
            settingsPane.setTranslateX(0);
            settingsPane.setTranslateY(0);
            AsteroidAdventureApp.showMainScreen(primaryStage);
        });

        // Set alignment for buttons and add them to the grid pane
        GridPane.setHalignment(saveButton, HPos.RIGHT);
        GridPane.setHalignment(backButton, HPos.LEFT);
        settingsPane.add(saveButton, 0, 7);
        settingsPane.add(backButton, 1, 7);

        // Configure alignment and appearance of the main grid pane
        settingsPane.setAlignment(Pos.CENTER);

        // Create the settings scene
        Scene settingsScene = new Scene(settingsPane, 950, 700);
        TranslateTransition settingsTransition = new TranslateTransition(Duration.seconds(2), settingsPane);
        settingsTransition.setFromY(-settingsPane.getHeight());
        settingsTransition.setToY(0);
        settingsTransition.play();
        primaryStage.setScene(settingsScene);
        settingsTransition.play();
    }

    // Method to validate and set the values for game settings
    private static void validateAndSetValues() {
        int mapSize, numPirates, numAsteroids, numTreasures, numMissiles, numBoosters;

        try {
            mapSize = Integer.parseInt(txtMapSize.getText());
            numPirates = Integer.parseInt(txtNumOfPirates.getText());
            numAsteroids = Integer.parseInt(txtNumOfAsteroids.getText());
            numTreasures = Integer.parseInt(txtNumOfTreasures.getText());
            numMissiles = Integer.parseInt(txtNumOfMissiles.getText());
            numBoosters = Integer.parseInt(txtNumOfBoosters.getText());

            // Validate input values
            if (mapSize > 50 || mapSize < 10) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Map size should be between 10 and 50.");
                return;
            }

            // Update the settings values
            MapSize = mapSize;
            NumOfPirates = numPirates;
            NumOfAsteroids = numAsteroids;
            NumOfTreasures = numTreasures;
            NumOfMissiles = numMissiles;
            NumOfBoosters = numBoosters;

            showAlert(Alert.AlertType.INFORMATION, "Success", "Settings saved successfully.");
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Invalid Input", "Please enter only numbers.");
        }
    }

    // Method to show an alert dialog
    private static void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
