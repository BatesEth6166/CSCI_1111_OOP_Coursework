package application;

public enum Type {

    Ship,
    Blank,
    Pirate,
    Asteroid,
    Treasure,
  
    Exit

}
