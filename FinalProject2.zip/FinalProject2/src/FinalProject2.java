import java.util.Scanner;
public class FinalProject2 {
	static GameSettings gameSettings;
	static GameGrid gameGrid;
	static PlayerShip playerShip;
	static PirateShip pirateShip;
	
    public static void main(String[] args) {
    	displayOpeningSequence();
    	initializeGame();
    	gameLoop();
    }
    
    public static void displayOpeningSequence() {
        Scanner scanner = new Scanner(System.in);
        int tutorial = 0;
        // Game info
        System.out.println("Welcome to Asteroid Adventure!");
        System.out.println("A game by Ethan Bates");
        System.out.println("Enter 1 if you would like a full tutorial of all game mechanics and aspects, or enter 2 if you'd rather just get to the game: ");
        tutorial = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        if (tutorial == 1) {
            displayTutorial();
        }
    }
    
    public static void initializeGame() {
        gameSettings = new GameSettings();
        gameSettings.changeSettings();
        playerShip = new PlayerShip(gameSettings.getNumMissiles(), gameSettings.getNumBoosters(), gameSettings);
        gameGrid = new GameGrid(gameSettings.getMapSize());
        pirateShip = new PirateShip(gameSettings.getNumPirates());
        gameGrid.generateMap();
     
        gameGrid.placePlayerShip(playerShip);
        
        gameGrid.generateHazards(gameSettings.getNumAsteroids(), gameSettings.getNumTreasures());
        
      
        gameGrid.placePirateShips(pirateShip, playerShip);
        
    }

    
    public static void gameLoop() {
        // Start game loop
        boolean gameRunning = true;
        while (gameRunning) {
            gameGrid.displayGrid();
            playerShip.displayStatus();
            // Player's turn
            playerShip.playerTurn(gameGrid);
            // Check game over conditions at the end of player turn
            if (pirateShip.isPlayerCaught(playerShip)) {
                System.out.println("The pirate captured you. Game over!");
                gameRunning = false;
            }
            // Pirate's turn
            pirateShip.makeMove(gameGrid, playerShip);
            // Check game over conditions at the end of pirate's turn
            if (pirateShip.isPlayerCaught(playerShip)) {
                System.out.println("The pirate captured you. Game over!");
                gameRunning = false;
            }
        }
    }

    public static void displayTutorial() {
        System.out.println("This game is highly customizable, with each map randomized, you can select different amounts of abilities such as missiles and boosters, more or fewer enemy pirates, asteroids, and so on!");
        System.out.println("Your ship 'A' moves using 'w' for up, 'a' for left, 's' for down, and 'd' for right.");
        System.out.println("If you choose to have boosters or missiles enabled, you can use boosters to fly past pirates who are right on your tail or in front of you without being caught, and missiles can destroy pirates, asteroids, or even treasures if you aren't careful.");
        System.out.println("If you choose a lot of asteroids in your map, it's a good idea to have a lot of missiles as you may need to clear your way to the exit point.");
        System.out.println("Win the game by reaching the exit point without getting caught by pirates. You can try to collect as many treasures as possible and race against your own move count to try and win in as few moves as possible.");
        System.out.println("-------------------------------");
    }

	public static void endGame() {
		System.out.println("Thank you for playing Asteroid Adventure! Game Over!");
	}
}
