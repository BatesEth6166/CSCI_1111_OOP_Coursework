import java.util.Scanner;

public class PlayerShip {
    private int playerRow;
    private int playerCol;
    private int treasureCount;
    private int numMissiles;
    private int numBoosters;
    private int turnCount;

    public PlayerShip(int numMissiles, int numBoosters, GameSettings gameSettings) {
        this.numMissiles = numMissiles;
        this.numBoosters = numBoosters;
        this.turnCount = 0;
    }

    public PlayerShip(GameSettings gameSettings) {
        this.numMissiles = gameSettings.getNumMissiles();
        this.numBoosters = gameSettings.getNumBoosters();
        this.turnCount = 0;
    }

    public int getPlayerRow() {
        return playerRow;
    }

    public int getPlayerCol() {
        return playerCol;
    }

    public int getTreasureCount() {
        return treasureCount;
    }

    public void playerTurn(GameGrid gameGrid) {
        turnCount++;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Choose one: 1 = move, 2 = boost, 3 = fire missile: ");
        String input = scanner.nextLine();
        switch (input) {
            case "1":
                makeMove(gameGrid);
                break;
            case "2":
                useBoost(gameGrid);
                break;
            case "3":
                useMissile(gameGrid);
                break;
            default:
                System.out.println("Invalid input, try again.");
                playerTurn(gameGrid);
        }
    }

    public void makeMove(GameGrid gameGrid) {
        Scanner scanner = new Scanner(System.in);
        boolean isValidMove = false;
        int newRow = playerRow;
        int newCol = playerCol;
        while (!isValidMove) {
            System.out.print("Enter your move (w(up)/s(down)/a(left)/d(right)): ");
            String input = scanner.nextLine();
            switch (input) {
                case "w":
                    newRow = playerRow - 1;
                    newCol = playerCol;
                    break;
                case "s":
                    newRow = playerRow + 1;
                    newCol = playerCol;
                    break;
                case "a":
                    newRow = playerRow;
                    newCol = playerCol - 1;
                    break;
                case "d":
                    newRow = playerRow;
                    newCol = playerCol + 1;
                    break;
                default:
                    System.out.println("Invalid input, try again.");
                    makeMove(gameGrid);
            }
            if (isValidMove(newRow, newCol, gameGrid)) {
                isValidMove = true;
            } else {
                System.out.println("Invalid move. Try again.");
            }

            if (gameGrid.isExitPoint(newRow, newCol)) {
                System.out.println("You reached the exit point with " + treasureCount + " treasures!");
                displayStatus();
                FinalProject2.endGame();
            }
        }

        boolean treasureChecker = gameGrid.isTreasure(newRow, newCol);
        if (treasureChecker) {
            treasureCount++;
        }

        gameGrid.movePlayerShip(playerRow, playerCol, newRow, newCol);
        playerRow = newRow;
        playerCol = newCol;
    }

    public void useBoost(GameGrid gameGrid) {
        if (numBoosters <= 0) {
            System.out.println("You have no boosters remaining.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter boost direction (w/up, s/down, a/left, d/right): ");
        String input = scanner.nextLine();
        int newRow = playerRow;
        int newCol = playerCol;
        int boostDistance = 0;

        switch (input) {
            case "w":
                while (isValidMove(newRow - 1, newCol, gameGrid) && !gameGrid.isObstacle(newRow - 1, newCol) && boostDistance < 4) {
                    newRow--;
                    boostDistance++;
                }
                break;
            case "s":
                while (isValidMove(newRow + 1, newCol, gameGrid) && !gameGrid.isObstacle(newRow + 1, newCol) && boostDistance < 4) {
                    newRow++;
                    boostDistance++;
                }
                break;
            case "a":
                while (isValidMove(newRow, newCol - 1, gameGrid) && !gameGrid.isObstacle(newRow, newCol - 1) && boostDistance < 4) {
                    newCol--;
                    boostDistance++;
                }
                break;
            case "d":
                while (isValidMove(newRow, newCol + 1, gameGrid) && !gameGrid.isObstacle(newRow, newCol + 1) && boostDistance < 4) {
                    newCol++;
                    boostDistance++;
                }
                break;
            default:
                System.out.println("Invalid direction. Boost usage failed.");
                return;
        }
       

        if (gameGrid.isExitPoint(newRow, newCol)) {
            System.out.println("Game Over! You reached the exit point with " + treasureCount + " treasures!");
            FinalProject2.endGame();
        }

        boolean treasureChecker = gameGrid.isTreasure(newRow, newCol);
        if (treasureChecker) {
            treasureCount++;
        }

        gameGrid.movePlayerShip(playerRow, playerCol, newRow, newCol);
        playerRow = newRow;
        playerCol = newCol;
        System.out.println("Boost distance reached");
        numBoosters--;
    }

    public void useMissile(GameGrid gameGrid) {
        if (numMissiles <= 0) {
            System.out.println("You have no missiles remaining.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Missile direction (w/up, s/down, a/left, d/right): ");
        String input = scanner.nextLine();

        int changeInRow = 0;
        int changeInCol = 0;

        switch (input) {
            case "w":
                changeInRow = -1;
                break;
            case "s":
                changeInRow = 1;
                break;
            case "a":
                changeInCol = -1;
                break;
            case "d":
                changeInCol = 1;
                break;
            default:
                System.out.println("Invalid direction. Missile usage failed.");
                return;
        }

        int newRow = playerRow;
        int newCol = playerCol;

        while (gameGrid.isValidPosition(newRow, newCol)) {
            newRow += changeInRow;
            newCol += changeInCol;

            GridObject targetObject = gameGrid.getObjectAtPosition(newRow, newCol);

            if (targetObject.isPirate()) {
                gameGrid.clearSquare(newRow, newCol);
                targetObject.destroyGridObject();

                System.out.println("Pirate ship destroyed!");
                numMissiles--;
                return;
            }

            if (targetObject.isTreasure() || targetObject.isAsteroid()) {
                gameGrid.clearSquare(newRow, newCol);

                if (targetObject.isTreasure()) {
                    System.out.println("Treasure destroyed!");
                } else {
                    System.out.println("Asteroid destroyed!");
                }

                numMissiles--;
                return;
            }

            if (gameGrid.isExitPoint(newRow, newCol)) {
                break;
            }
        }

        System.out.println("Missile missed the target.");
        numMissiles--;
    }


    public void setPlayerPosition(int row, int col) {
        playerRow = row;
        playerCol = col;
    }

    private boolean isValidMove(int row, int col, GameGrid gameGrid) {
        return gameGrid.isValidPosition(row, col) && !gameGrid.isObstacle(row, col) && !gameGrid.isAsteroid(row, col);
    }

    public void displayStatus() {
        System.out.println("Player Status:");
        System.out.println("Treasures Collected: " + treasureCount);
        System.out.println("Missiles Remaining: " + numMissiles);
        System.out.println("Boosters Remaining: " + numBoosters);
        System.out.println("Turn Count: " + turnCount);
    }
}
