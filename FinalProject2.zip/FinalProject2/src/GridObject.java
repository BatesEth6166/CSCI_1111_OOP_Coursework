public class GridObject {
    public String token;

    public GridObject() {
        this.token = "-";
    }

    public GridObject(String token) {
        this.token = token;
    }


    public boolean isEmpty() {
        return token.equals("-") || token.equals("");
    }

    public boolean isAsteroid() {
        return token.equals("O");
    }

    public boolean isTreasure() {
        return token.equals("T");
    }

    public boolean isPirate() {
        return token.equals("X");
    }

    public boolean isPlayerShip() {
        return token.equals("A");
    }

    public boolean isMissile() {
        return token.equals("M");
    }

    public boolean isExitPoint() {
        return token.equals("H");
    }
    
    public void destroyGridObject() {
    	token = "-";
    }
}
