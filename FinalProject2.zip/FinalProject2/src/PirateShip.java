public class PirateShip {
    private final int numPirates;
    private final int[][] piratePositions;
    private final GridObject[] pirateObjects;

    public PirateShip(int numPirates) {
        this.numPirates = numPirates;
        this.piratePositions = new int[numPirates][2];
        this.pirateObjects = new GridObject[numPirates];
        for (int i = 0; i < numPirates; i++) {
            this.pirateObjects[i] = new GridObject("X");
        }
    }

    public int getNumPirates() {
        return numPirates;
    }

    public void setPiratePosition(int pirateIndex, int row, int col) {
        if (pirateIndex >= 0 && pirateIndex < numPirates) {
            piratePositions[pirateIndex][0] = row;
            piratePositions[pirateIndex][1] = col;
        } else {
            System.out.println("Invalid pirate index.");
        }
    }

    public GridObject getPirateObject(int pirateIndex) {
        if (pirateIndex >= 0 && pirateIndex < numPirates) {
            return pirateObjects[pirateIndex];
        } else {
            System.out.println("Invalid pirate index.");
            return null;
        }
    }
	//Checks if the player is caught
	public boolean isPlayerCaught(PlayerShip playerShip) {
		int playerRow = playerShip.getPlayerRow();
		int playerCol = playerShip.getPlayerCol();
		for (int i = 0; i < numPirates; i++) {
			int pirateRow = piratePositions[i][0];
			int pirateCol = piratePositions[i][1];
			if (pirateRow == playerRow && pirateCol == playerCol) {
				return true;
			}
		}
		return false;
	}
	//moves the pirate ship
	public void makeMove(GameGrid gameGrid, PlayerShip playerShip) {
		for (int pirateIndex = 0; pirateIndex < numPirates; pirateIndex++) {
			int currentRow = piratePositions[pirateIndex][0];
			int currentCol = piratePositions[pirateIndex][1];
			int newRow = currentRow;
			int newCol = currentCol;
			int playerRow = playerShip.getPlayerRow();
			int playerCol = playerShip.getPlayerCol();


			// Calculate the difference in coordinates between the pirate ship and the player's ship
			int rowDiff = playerRow - currentRow;
			int colDiff = playerCol - currentCol;


			// Determine which way to move
			if (Math.abs(rowDiff) > Math.abs(colDiff)) {
				newRow = currentRow + Integer.compare(rowDiff, 0); // Move towards the player row
			} else {
				newCol = currentCol + Integer.compare(colDiff, 0); // Move towards the player column
			}


			// Check if the move is valid and not obstructed by an asteroid or another pirate ship
			if (!isValidMove(currentRow, currentCol, newRow, newCol, gameGrid)) {
				// If the move is not valid, try alternative moves
				if (Math.abs(rowDiff) > Math.abs(colDiff)) {
					newCol = currentCol; // Stay in the same column
					newRow = currentRow + Integer.compare(rowDiff, 0); // Move towards the player row
				} else {
					newRow = currentRow; // Stay in the same row
					newCol = currentCol + Integer.compare(colDiff, 0); // Move towards the player column
				}
				// Check if the alternative move is valid
				if (!isValidMove(currentRow, currentCol, newRow, newCol, gameGrid)) {
					// If the alternative move is also not valid, stay still
					newRow = currentRow;
					newCol = currentCol;
				}
			}


			// Update the pirate ship's position
			gameGrid.movePirateShip(this, pirateIndex, currentRow, currentCol, newRow, newCol);
			piratePositions[pirateIndex][0] = newRow;
			piratePositions[pirateIndex][1] = newCol;
		}
	}


	//Checks if the move is valid, inside the map
	private boolean isValidMove(int currentRow, int currentCol, int newRow, int newCol, GameGrid gameGrid) {
		int mapSize = gameGrid.getMapSize();
		if (newRow < 0 || newRow >= mapSize || newCol < 0 || newCol >= mapSize) {
			return false; 
		}
		if (gameGrid.isObstacle(newRow, newCol) || gameGrid.isAsteroid(newRow, newCol)) {
			return false; 
		}
		return true;
	}
}
