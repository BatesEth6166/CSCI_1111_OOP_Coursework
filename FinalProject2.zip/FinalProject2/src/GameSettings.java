import java.util.Scanner;
public class GameSettings {
	private int mapSize;
	private int numPirates;
	private int numAsteroids;
	private int numTreasures;
	private int numMissiles;
	private int numBoosters;
	//sets default values for settings
	public GameSettings() {
		this.mapSize = 10;
		this.numMissiles = 0;
		this.numBoosters = 0;
		this.numPirates = 1;
		this.numAsteroids = 10;
		this.numTreasures = 5;
	}
	//Changes game settings
	public void changeSettings() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Change Game Settings:");
	    
	    // Prompt for Map Size
	    int newSize = 0;
	    boolean validSize = false;
	    while (!validSize) {
	        System.out.print("Enter Map Size (minimum 10): ");
	        newSize = scanner.nextInt();
	        
	        if (newSize >= 10) {
	            validSize = true;
	            mapSize = newSize;
	        } else {
	            System.out.println("Invalid map size. Please enter a value greater than or equal to 10.");
	        }
	    }
	    
	    // Prompt for Number of Pirate Ships
	    System.out.print("Enter Number of Pirate Ships: ");
	    int newPirates = 0;
	    boolean validPirates = false;
	    while (!validPirates) {
	        if (scanner.hasNextInt()) {
	            newPirates = scanner.nextInt();
	            validPirates = true;
	        } else {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            scanner.next(); // Clear the invalid input from the scanner
	        }
	    }
	    numPirates = newPirates;
	    
	    // Prompt for Number of Asteroids
	    System.out.print("Enter Number of Asteroids: ");
	    int newAsteroids = 0;
	    boolean validAsteroids = false;
	    while (!validAsteroids) {
	        if (scanner.hasNextInt()) {
	            newAsteroids = scanner.nextInt();
	            validAsteroids = true;
	        } else {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            scanner.next(); // Clear the invalid input from the scanner
	        }
	    }
	    numAsteroids = newAsteroids;
	    
	    // Prompt for Number of Treasures
	    System.out.print("Enter Number of Treasures: ");
	    int newTreasures = 0;
	    boolean validTreasures = false;
	    while (!validTreasures) {
	        if (scanner.hasNextInt()) {
	            newTreasures = scanner.nextInt();
	            validTreasures = true;
	        } else {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            scanner.next(); // Clear the invalid input from the scanner
	        }
	    }
	    numTreasures = newTreasures;
	    
	    // Prompt for Number of Missiles
	    System.out.print("Enter Number of Missiles: ");
	    int newMissiles = 0;
	    boolean validMissiles = false;
	    while (!validMissiles) {
	        if (scanner.hasNextInt()) {
	            newMissiles = scanner.nextInt();
	            validMissiles = true;
	        } else {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            scanner.next(); // Clear the invalid input from the scanner
	        }
	    }
	    numMissiles = newMissiles;
	    
	    // Prompt for Number of Boosters
	    System.out.print("Enter Number of Boosters: ");
	    int newBoosters = 0;
	    boolean validBoosters = false;
	    while (!validBoosters) {
	        if (scanner.hasNextInt()) {
	            newBoosters = scanner.nextInt();
	            validBoosters = true;
	        } else {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            scanner.next(); // Clear the invalid input from the scanner
	        }
	    }
	    numBoosters = newBoosters;
	    
	    System.out.println("Game settings updated successfully.");
	    System.out.println();
	}


	public int getNumPirates() {
		return numPirates;
	}
	//gets number of asteroids to place
	public int getNumAsteroids() {
		return numAsteroids;
	}
	//gets number of treasures to place
	public int getNumTreasures() {
		return numTreasures;
	}
	//gets number of missiles
	public int getNumMissiles() {
		return numMissiles;
	}
	//sets number of missiles
	public void setNumMissiles(int numMissiles) {
		this.numMissiles = numMissiles;
	}
	//gets number of boosters
	public int getNumBoosters() {
		return numBoosters;
	}
	//sets number of boosters
	public void setNumBoosters(int numBoosters) {
		this.numBoosters = numBoosters;
	}
	//Gets map size
	public int getMapSize() {
		return mapSize;
	}
}
