import java.util.Random;

public class GameGrid {
    private final GridObject[][] grid;
    private final int mapSize;

    public GameGrid(int mapSize) {
        this.mapSize = mapSize;
        this.grid = new GridObject[mapSize][mapSize];
        initializeGrid();
        
    }

    // Initialize the grid with empty objects
    private void initializeGrid() {
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                grid[i][j] = new GridObject("-");
            }
        }
    }
 
    // Generates map and fills it with objects
    public void generateMap() {
        Random random = new Random();
        initializeGrid();
       
        // Spawn exit point randomly
        int exitRow = random.nextInt(mapSize);
        int exitCol = random.nextInt(mapSize);
        while (!grid[exitRow][exitCol].isEmpty() || isSurroundedByAsteroids(exitRow, exitCol)) {
            exitRow = random.nextInt(mapSize);
            exitCol = random.nextInt(mapSize);
        }
        
        grid[exitRow][exitCol] = new GridObject("H");
    }
    
    public void generateHazards(int numAsteroids, int numTreasures)
    {
    	Random random = new Random();
    	// Spawn asteroids randomly
        int asteroidCount = 0;
        while (asteroidCount < numAsteroids) {
            int row = random.nextInt(mapSize);
            int col = random.nextInt(mapSize);
            if (grid[row][col].isEmpty()) {
                grid[row][col] = new GridObject("O");
                asteroidCount++;
            }
        }

        // Spawn treasures randomly
        for (int i = 0; i < numTreasures; i++) {
            int row = random.nextInt(mapSize);
            int col = random.nextInt(mapSize);
            if (grid[row][col].isEmpty()) {
                grid[row][col] = new GridObject("T");
            } else {
                i--;
            }
        }
    }
    // Check if a position is surrounded by asteroids
    private boolean isSurroundedByAsteroids(int row, int col) {
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] direction : directions) {
            int newRow = row + direction[0];
            int newCol = col + direction[1];
            if (isValidPosition(newRow, newCol) && !grid[newRow][newCol].isAsteroid()) {
                return false;
            }
        }
        return true;
    }
 // Places the player ship on the map
    public void placePlayerShip(PlayerShip playerShip) {
        Random random = new Random();
        int playerRow = random.nextInt(mapSize);
        int playerCol = random.nextInt(mapSize);

        while (!isValidPlayerShipPosition(playerRow, playerCol)) {
            playerRow = random.nextInt(mapSize);
            playerCol = random.nextInt(mapSize);
        }

        playerShip.setPlayerPosition(playerRow, playerCol);
        grid[playerRow][playerCol] = new GridObject("A");
    }
    
    // Check if a position is valid
    boolean isValidPosition(int row, int col) {
        return row >= 0 && row < mapSize && col >= 0 && col < mapSize;
    }

    // Places the pirate ship(s) on the map
    public void placePirateShips(PirateShip pirateShip, PlayerShip playerShip) {
        Random random = new Random();
        for (int i = 0; i < pirateShip.getNumPirates(); i++) {
            int pirateRow = random.nextInt(mapSize);
            int pirateCol = random.nextInt(mapSize);
            int playerRow = playerShip.getPlayerRow();
            int playerCol = playerShip.getPlayerCol();
            int distance = Math.abs(playerRow - pirateRow) + Math.abs(playerCol - pirateCol);

            while (distance < 5 || !grid[pirateRow][pirateCol].isEmpty()) {
                pirateRow = random.nextInt(mapSize);
                pirateCol = random.nextInt(mapSize);
                distance = Math.abs(playerRow - pirateRow) + Math.abs(playerCol - pirateCol);
            }

            pirateShip.setPiratePosition(i, pirateRow, pirateCol);
            grid[pirateRow][pirateCol] = pirateShip.getPirateObject(i);
        }
    }

    // Checks if the player spawn position is valid
    private boolean isValidPlayerShipPosition(int row, int col) {
        for (int i = Math.max(0, row - 5); i <= Math.min(mapSize - 1, row + 5); i++) {
            for (int j = Math.max(0, col - 5); j <= Math.min(mapSize - 1, col + 5); j++) {
                if (!grid[i][j].isEmpty() && !grid[i][j].isExitPoint()) {
                    return false;
                }
            }
        }

       for (int i = Math.max(0, row - 1); i <= Math.min(mapSize - 1, row + 1); i++) {
            for (int j = Math.max(0, col - 1); j <= Math.min(mapSize - 1, col + 1); j++) {
                if (grid[i][j].isEmpty()) {
                   return true;
                }
            }
        }
    	if(grid[row][col].isEmpty()) return true;
        return false;
    }

    // Displays the grid
    public void displayGrid() {
    	System.out.println("Displaying grid");
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                System.out.print(grid[i][j].token + " ");
            }
            System.out.println();
        }
    }

    // Checks if a position is the exit point
    public boolean isExitPoint(int row, int col) {
        return grid[row][col].isExitPoint();
    }

    // Checks if a position is an asteroid
    public boolean isAsteroid(int row, int col) {
        return grid[row][col].isAsteroid();
    }

    // Checks if a position is an obstacle (pirate or asteroid)
    public boolean isObstacle(int row, int col) {
        return grid[row][col].isPirate() || grid[row][col].isAsteroid();
    }
    
    public boolean isTreasure(int row, int col) {
        return grid[row][col].token.equals("T");
    }

    // Moves the player ship on the grid
    public void movePlayerShip(int playerRow, int playerCol, int newRow, int newCol) {
        grid[playerRow][playerCol] = new GridObject();
        grid[newRow][newCol] = new GridObject("A");
    }

    // Moves the pirate ship on the grid
    public void movePirateShip(PirateShip pirateShip, int pirateIndex, int currentRow, int currentCol, int newRow, int newCol) {
        GridObject currentPosition = grid[currentRow][currentCol];
        GridObject newPosition = grid[newRow][newCol];

        if (currentPosition.isExitPoint()) {
            grid[currentRow][currentCol] = new GridObject("H"); // Preserve the exit point
        } else if (!currentPosition.isEmpty() && !currentPosition.isExitPoint()) {
            grid[currentRow][currentCol] = new GridObject(); // Empty the current position
        }

        if (newPosition.isEmpty()) {
            grid[newRow][newCol] = pirateShip.getPirateObject(pirateIndex); // Move the pirate ship
        } else if (newPosition.isPlayerShip()) {
            grid[newRow][newCol] = newPosition; // Player ship is captured
        } else if (newPosition.isMissile()) {
            grid[newRow][newCol] = new GridObject(); // Destroy pirate with missile
        }

        pirateShip.setPiratePosition(pirateIndex, newRow, newCol);
    }

    // Clears a square
    public void clearSquare(int row, int col) {
        grid[row][col] = new GridObject();
    }
    public int getMapSize() {
        return mapSize;
    }
    public GridObject getObjectAtPosition(int row, int col) {
        return grid[row][col];
    }
}
